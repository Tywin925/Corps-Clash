#ifndef TANK_H
#define TANK_H
#include "Character.h"
class Tank : public Character {
public:
  Tank(std::string characterNameInput, int healthInput, int attackInput,
       int defenseInput) {
    characterName = characterNameInput;
    health = healthInput;
    attack = attackInput;
    defense = defenseInput;
    maxHP = healthInput;
  } //SETS THE TANK STATS

  ~Tank() { std::cout << characterName << " has been defeated" << std::endl; }

  void getCharacterInfo() const override { //OUTPUTS CHARACTER INFO
    std::cout << std::endl << "Tank" << std::endl;
    std::cout << "HP: 20" << std::endl;
    std::cout << "Attack: 5" << std::endl;
    std::cout << "Defense: 4" << std::endl;
    std::cout << "Passive: activates once character performs an attack. If Tank has "
              << std::endl
              << "more than half of its max HP, damage will increase by 2."
              << std::endl
              << std::endl;
    std::cout << "Special Attack: Tank will do damage based on enemy defense."
              << std::endl
              << std::endl;
    std::cout << "Ability: Tank will unleash an attack that stuns enemy active "
              << std::endl
              << "character. This forces enemy player to switch character and "
              << std::endl
              << "ending their turn." << std::endl
              << std::endl;
  }
  int activatePassive() override {
    if (health > maxHP / 2) {
      attack = defaultAttack + 2; //AFTER AN ATTACK, TANK WILL DO EXTRA DAMAGE IF HEALTH IS GREATER THAN HALF
    } else {
      attack = defaultAttack;
    }
    return attack;
  }
  int getSpecialAttack(int value) override { return attack + value; } //TANK WILL DO EXTRA DAMAGE BASED ON VALUE

private:
  const int defaultAttack = 5;
};
#endif