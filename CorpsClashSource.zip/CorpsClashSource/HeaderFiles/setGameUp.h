#ifndef SET_GAME_UP
#define SET_GAME_UP

#include "ClassFiles/Team.h"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>

void outputMenu(std::string startTXT) {
  std::ifstream fin;
  std::string line;
  fin.open(startTXT);
  while (getline(fin, line)) { //WILL OUTPUT EVERYTHING IN THE TXT FILE
    std::cout << line << std::endl;
  }
  fin.close(); 
}

void startInput(std::string &start) {
  while (start != "1" && start != "2" && start != "3") {
    std::cout << "Please start or exit" << std::endl; //MAKES SURE THE GAME CHOOSES THESE OPTIONS
    std::cin >> start; 
  }
}

void chooseTeam(Team *&player, const int rosterSize, int i) {
  std::string teamName, nameList[3], name, s, num, numInput;
  int healthList[3], attackList[3], defenseList[3], health, attack, defense;
  std::cout << "Choose your team name player " << i << std::endl;
  std::cin >> teamName; //ASKS FOR THE TEAM NAME
  outputMenu("TextFiles/Characters.txt"); 
  for (int j = 0; j < rosterSize; j++) {
    std::cout << "Please enter a digit from 1 to 5 to choose a character"
      << std::endl;
    std::cin >> numInput; //ASKS FOR INPUT TO CHOOSE A CHARACTER
    while (numInput != "1" && numInput != "2" && numInput != "3" &&
           numInput != "4" && numInput != "5") {
      std::cout << "Please enter a valid character digit" << std::endl;
      std::cin >> numInput;
    }
    std::ifstream fin;
    fin.open("TextFiles/Characters.txt"); //OPENS CHARACTERS FILE
    while (fin >> num) {
      fin >> name >> s >> health >> s >> attack >> s >> defense;
      if (num == numInput) { //IF CHARACTER DIGIT MATCHES INPUT THEN IT WILL FILE INPUT THEIR FOLLOWING STATS INTO LIST
        nameList[j] = name; //THE J VALUE IS THE INDEX OF THE CHARACTER
        healthList[j] = health; // SETS J CHARACTER HEALTH
        attackList[j] = attack; //SETS J CHARACTER ATTACK
        defenseList[j] = defense; //SETS J CHARACTER DEFENSE
        fin.close();
        break;
      }
    }
  }
  player = new Team(teamName, nameList, healthList, attackList, defenseList,
                    rosterSize); //CREATES THE TEAM
}

void SaveFile(Team *Player1, Team *Player2) {
  std::ofstream fout("TextFiles/SaveFile.txt");
  fout << Player1->getTeamName() << std::endl; //TEAM NAME
  fout << Player1->getRosterSize() << std::endl; //SAVES AMOUNT OF CHARACTERS THEY HAVE
  for (int i = 0; i < Player1->getRosterSize(); i++) { //SAVES PLAYER 1 CHARACTERS
    fout << Player1->getCharacterAtIndex(i).getCharacter() << std::endl;
    fout << Player1->getCharacterAtIndex(i).getHealth() << std::endl;
    fout << Player1->getCharacterAtIndex(i).getAttack() << std::endl;
    fout << Player1->getCharacterAtIndex(i).getDefense() << std::endl;
  }
  fout << std::endl;
  fout << Player2->getTeamName() << std::endl;
  fout << Player2->getRosterSize() << std::endl;
  for (int i = 0; i < Player2->getRosterSize(); i++) { //SAVES PLAYER 2 CHARACTERS
    fout << Player2->getCharacterAtIndex(i).getCharacter() << std::endl;
    fout << Player2->getCharacterAtIndex(i).getHealth() << std::endl;
    fout << Player2->getCharacterAtIndex(i).getAttack() << std::endl;
    fout << Player2->getCharacterAtIndex(i).getDefense() << std::endl;
  }
  fout.close();
}

void loadGameFile(std::string textFile, Team *&player1, Team *&player2) {
  std::ifstream fin(textFile);
  std::string teamName, name, nameList[3];
  int health, attack, defense, rosterSize;
  int healthList[3], attackList[3], defenseList[3];

  fin >> teamName >> rosterSize;
  for (int i = 0; i < rosterSize; i++) {
    fin >> name >> health >> attack >> defense; //GETS THE STATS OF ALL THE CHARACTERS
    nameList[i] = name;
    healthList[i] = health;
    attackList[i] = attack;
    defenseList[i] = defense;
  }
  player1 = new Team(teamName, nameList, healthList, attackList, defenseList,
                     rosterSize); //CREATES THE TEAM FOR PLAYER 2 FOR 

  fin >> teamName >> rosterSize;
  for (int i = 0; i < rosterSize; i++) {
    fin >> name >> health >> attack >> defense; //GETS THE STATS OF ALL THE CHARACTERS
    nameList[i] = name;
    healthList[i] = health;
    attackList[i] = attack;
    defenseList[i] = defense;
  }
  player2 = new Team(teamName, nameList, healthList, attackList, defenseList,
                     rosterSize);//CREATES THE TEAM FOR PLAYER 2 FOR 
}
#endif