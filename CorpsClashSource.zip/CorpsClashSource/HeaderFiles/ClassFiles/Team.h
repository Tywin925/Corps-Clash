#ifndef TEAM_H
#define TEAM_H
#include <iostream>
#include <string>

#include "Assassin.h"
#include "Bruiser.h"
#include "Character.h"
#include "Marksman.h"
#include "Support.h"
#include "Tank.h"

class Team {
public:
  Team() {
    teamName = "Anonymous";
    rosterSize = 0;
    for (int i = 0; i < 3; i++) {
      roster[i] = NULL;
    }
    turnPoints = 0;
  }
  Team(std::string nameInput, std::string name[], int health[], int attack[],
       int defense[], int size) { //CONSTRUCTOR WILL CREATE THE CHARACTER WITHT THE LIST OF STATS
    teamName = nameInput;
    turnPoints = 10; 
    rosterSize = size;
    for (int i = 0; i < size; i++) { //CHECKS THE NAME AND CREATES THE RIGHT CHARACTER
      if (name[i] == "Assassin") {
        roster[i] = new Assassin(name[i], health[i], attack[i], defense[i]);
      } else if (name[i] == "Marksman") {
        roster[i] = new Marksman(name[i], health[i], attack[i], defense[i]);
      } else if (name[i] == "Bruiser") {
        roster[i] = new Bruiser(name[i], health[i], attack[i], defense[i]);
      } else if (name[i] == "Tank") {
        roster[i] = new Tank(name[i], health[i], attack[i], defense[i]);
      } else if (name[i] == "Support") {
        roster[i] = new Support(name[i], health[i], attack[i], defense[i]);
      }
    }
  }
  ~Team() { std::cout << "Goodbye " << teamName << std::endl; }

  void useAttack(Team *&otherPlayer, int target) { 
    otherPlayer->getCharacterAtIndex(target).setHealth( //SETS THE HEALTH BASED ON THE VALUE INSIDE
        otherPlayer->getCharacterAtIndex(target).getHealth() + 
        otherPlayer->getCharacterAtIndex(target).getDefense() - //SUBTRACTS THE TARGET'S HEALTH (PLUS THEIR DEFENSE) BY THE ATTACK VALUE
        roster[active]->getAttack());
  }
  void useSpecialAttack(Team *&otherPlayer, int target, int defenseValue) {
    otherPlayer->getCharacterAtIndex(target).setHealth(
        otherPlayer->getCharacterAtIndex(target).getHealth() +
        otherPlayer->getCharacterAtIndex(target).getDefense() - //SUBTRACTS THE TARGET'S HEALTH (PLUS THEIR DEFENSE) BY THE SPECIAL ATTACK VALUE
        roster[active]->getSpecialAttack(defenseValue)); 
  }

  void removeCharacter(int target) { //REMOVES A CHARACTER AND MOVES THE ROSTER DOWN
    delete roster[target];
    for (int i = target; i < rosterSize; i++) {
      roster[i] = roster[i + 1];
    } 
    rosterSize--;
  }
  void useSwitch(int target) { //SWITCHES ACTIVE CHARACTER
    Character *tempCharacter = roster[active];
    roster[active] = roster[target - 1];
    roster[target - 1] = tempCharacter;
  }

  void resetTurnPoints() { turnPoints = 10; }

  void decreaseTurnPoints(int pointsDeduct) { turnPoints -= pointsDeduct; } //RESETS TURN POINTS

  std::string getTeamName() { return teamName; } 
  int getRosterSize() { return rosterSize; }
  int getTurnPoints() { return turnPoints; }


  Character &getCharacterAtIndex(int index) { return *roster[index]; } //RETURNS THE CHARACTER OF INDEX

private:
  std::string teamName;
  Character *roster[3];
  int rosterSize;
  int turnPoints;
  const int active = 0;
};
#endif