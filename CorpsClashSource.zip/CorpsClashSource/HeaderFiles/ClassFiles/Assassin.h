#ifndef ASSASSIN_H
#define ASSASSIN_H
#include "Character.h"
class Assassin : public Character {
public:
  Assassin(std::string characterNameInput, int healthInput, int attackInput,
           int defenseInput) {
    characterName = characterNameInput;
    health = healthInput;
    attack = attackInput;
    defense = defenseInput;
    maxHP = healthInput;
  } //SETS THE ASSASSIN STATS

  ~Assassin() {
    std::cout << characterName << " has been defeated" << std::endl;
  }

  void getCharacterInfo() const override { //OUTPUTS CHARACTER INFO
    std::cout << std::endl << "Assassin" << std::endl;
    std::cout << "HP: 14" << std::endl;
    std::cout << "Attack: 8" << std::endl;
    std::cout << "Defense: 1" << std::endl << std::endl;
    std::cout << "Passive: Assassin will perform a crit after a certain amount"
              << std::endl
              << "of attacks used." << std::endl
              << std::endl;
    std::cout << "Special Attack: Assassin will perform an attack and heal."
              << std::endl
              << "based on enemy defenses." << std::endl
              << std::endl;
    std::cout << "Ability: Marksman will attack and gain the ability to switch "
              << std::endl
              << "to another character in the same turn." << std::endl
              << std::endl;
  }

  int activatePassive() override {
    crit++;
    if (crit == 2) { //EVERY 3RD ATTACK IS A CRIT
      crit = 0;
      attack = defaultAttack + 4;
    } else {
      attack = defaultAttack;
    }
    return attack;
  }
  int getSpecialAttack(int value) override {
    health += value;
    return attack; //ASSASSIN WILL HEAL BASED ON VALUE
  }

private:
  int crit = 0;
  const int defaultAttack = 8;
};
#endif