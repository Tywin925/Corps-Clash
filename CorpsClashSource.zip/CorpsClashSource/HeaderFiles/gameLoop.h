#ifndef GAME_LOOP
#define GAME_LOOP

#include "ClassFiles/Team.h"
#include "characterAbility.h"
#include "displayBoard.h"
#include "setGameUp.h"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>

void playerOption(int cost, Team *&attackingPlayer, Team *&defendingPlayer,
                  bool &playerTurn) {
  int active = 0, defenseValue;
  while (cost > attackingPlayer->getTurnPoints() && cost != 5 && cost != 6) {
    std::cout << "insufficient turn points. Try a different int" << std::endl;
    std::cin >> cost; //STOPS THE PLAYER FROM USING MORE TURNPOINTS THAN THEY HAVE
  }
  if (cost == 1) {
    if (attackingPlayer->getRosterSize() > 1) {
      int target;
      std::cout << "Choose a character to switch to " << std::endl;
      std::cin >> target;
      while (target <= 1 || target > attackingPlayer->getRosterSize()) {
        std::cout << "Choose a valid character to switch to " << std::endl;
        std::cin >> target;
      }
      attackingPlayer->useSwitch(target); //SWITCHES CHARACTER
      attackingPlayer->decreaseTurnPoints(cost); //DECREASES TURNPOINTS BY 1
    } else {
      attackingPlayer->decreaseTurnPoints(cost);
    }
  } else if (cost == 2) {
    attackingPlayer->useAttack(defendingPlayer, active); //USES A NORMAL ATTACK
    attackingPlayer->getCharacterAtIndex(active).activatePassive(); //ACTIVATES PASSIVE OF THE CHARACTER
    attackingPlayer->decreaseTurnPoints(cost); //DECREASES TURNPOINTS BY 2

  } else if (cost == 3) {
    defenseValue = defendingPlayer->getCharacterAtIndex(active).getDefense(); //GETS DEFENSE VALUE OF DEFENDING CHARACTER
    attackingPlayer->useSpecialAttack(defendingPlayer, active, defenseValue); //USES THAT DEFENSE VALUE TO ENCHANCE ATTACK
    attackingPlayer->getCharacterAtIndex(active).activatePassive();
    attackingPlayer->decreaseTurnPoints(cost); //DECREASES TURNPOINTS BY 3
  } else if (cost == 4) {
    characterAbility(attackingPlayer, defendingPlayer, playerTurn); //CALLS TO THE CHARACTER ABILITY FUNCTION 
    attackingPlayer->getCharacterAtIndex(active).activatePassive();
    attackingPlayer->decreaseTurnPoints(cost); //DECREASES TURNPOINTS BY 4
  } else if (cost == 6) {
    attackingPlayer->decreaseTurnPoints(attackingPlayer->getTurnPoints()); //DECREASES TURNPOINTS TO 0 IF PLAYER FORFEITS
  }
  for (int i = 0; i < defendingPlayer->getRosterSize(); i++) {
    if (defendingPlayer->getCharacterAtIndex(i).getHealth() <= 0) {
      defendingPlayer->removeCharacter(i); //CHECKS IF A CHARACTER DIED AND REMOVES THEM FROM THE ROSTER
    }
  }
  playerTurn = !playerTurn; //CHANGES THE TURN
}

void performGameLoop(Team *&Player1, Team *&Player2, int round) {
  int optionInput = 0;
  bool playerTurn = true;
  while (true) { 
    if (Player1->getTurnPoints() <= 0 && Player2->getTurnPoints() <= 0) { 
      Player1->resetTurnPoints(); //RESETS THE TURNPOINT BEFORE NEXT ROUND
      Player2->resetTurnPoints(); 
      break; //IF TURN POINTS OF BOTH PLAYER REACHES 0 THEN THE ROUND WILL END
    } 
    if (Player1->getRosterSize() == 0 || Player2->getRosterSize() == 0) {
      break; //ENDS GAME LOOP IF A PLAYER HAS 0 CHARACTERS
    }
    
    else if (playerTurn == true) { 
      if (Player1->getTurnPoints() <= 0) {
        playerTurn = !playerTurn;
      } else {
        outputMenu("TextFiles/Options.txt");
        std::cout << std::endl << "Player 1 choose an option" << std::endl;
        std::cin >> optionInput; //ASKS FOR INPUT FOR A CHOICE
        while (optionInput > 8) {
          std::cout << "Please input a valid integer" << std::endl;
          std::cin >> optionInput;
        }
        if (optionInput == 7) {
          Player1->getCharacterAtIndex(0).getCharacterInfo();
        } else {
          playerOption(optionInput, Player1, Player2, playerTurn); //PLAYEROPTION FUNCTION WILL CHANGE PLAYERTURN TO OTHER BOOL VALUE
          displayScoreBoard(Player1, Player2, round); //DISPLAYS THE GAME AFTER EVERYROUND
        }
      }
    }

    else if (playerTurn == false) {
      if (Player2->getTurnPoints() <= 0) {
        playerTurn = !playerTurn;
      } else {
        outputMenu("TextFiles/Options.txt");
        std::cout << std::endl << "Player 2 choose an option" << std::endl;
        std::cin >> optionInput; //ASKS FOR INPUT FOR A CHOICE
        while (optionInput > 8) {
          std::cout << "Please input a valid integer" << std::endl;
          std::cin >> optionInput;
        }
        if (optionInput == 7) {
          Player2->getCharacterAtIndex(0).getCharacterInfo();
        } else {
          playerOption(optionInput, Player2, Player1, playerTurn); //PLAYEROPTION FUNCTION WILL CHANGE PLAYERTURN TO OTHER BOOL VALUE
          displayScoreBoard(Player1, Player2, round);//DISPLAYS THE GAME AFTER EVERYROUND
        }
      }
    }
  }
}

#endif