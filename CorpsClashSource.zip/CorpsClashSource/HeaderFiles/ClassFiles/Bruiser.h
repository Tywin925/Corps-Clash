#ifndef BRUISER_H
#define BRUISER_H
#include "Character.h"
class Bruiser : public Character {
public:
  Bruiser(std::string characterNameInput, int healthInput, int attackInput,
          int defenseInput) {
    characterName = characterNameInput;
    health = healthInput;
    attack = attackInput;
    defense = defenseInput;
    maxHP = healthInput;
  } //SETS THE BRUISER STATS

  ~Bruiser() {
    std::cout << characterName << " has been defeated" << std::endl;
  }

  void getCharacterInfo() const override { //OUTPUTS CHARACTER INFO
    std::cout << std::endl << "Bruiser" << std::endl;
    std::cout << "HP: 18" << std::endl;
    std::cout << "Attack: 6" << std::endl;
    std::cout << "Defense: 3" << std::endl << std::endl;
    std::cout << "Passive: activates once bruiser performs an attack. If HP is "
              << std::endl
              << "less than half then bruiser will deal more damage."
              << std::endl
              << std::endl;
    std::cout << "Special Attack: Bruiser will deal devastating amounts of "
              << std::endl
              << "damage based on enemy defense and lose health in the process."
              << std::endl
              << std::endl;
    std::cout << "Ability: Bruiser will choose a non-active character to throw "
              << std::endl
              << "and will deal damage to the active character based on how "
              << std::endl
              << "much health the character being thrown has. This will switch "
                 "the active characters."
              << std::endl
              << std::endl;
  }
  int activatePassive() override {
    if (health < maxHP / 2) {
      attack = defaultAttack + 2;
    } else {
      attack = defaultAttack; //AFTER AN ATTACK, THE NEXT ATTACK WILL DO EXTRA DAMAGE IF BRUISER IS LOW
    }
    return attack;
  }
  int getSpecialAttack(int value) override {
    health -= value;
    return attack + value + value; //BRUISER WILL DO EXTRA DAMAGE BUT WILL SUFFER IN RETURN
  }

private:
  const int defaultAttack = 6;
};
#endif