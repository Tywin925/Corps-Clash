#ifndef DISPLAY_BOARD
#define DISPLAY_BOARD
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>

#include "ClassFiles/Team.h"

void displayCharacterInfo(Team *player1, Team *player2, int i) { //DISPLAYS THE CHARACTERS IN A CERTAIN FORMAT
  if (i == 0) {
    if (i < player1->getRosterSize()) { //IF CHARACTER IS 1ST THEN IT WILL OUTPUT (ACTIVE) NEXT TO IT
      std::cout << std::setw(20) << std::left
                << player1->getCharacterAtIndex(i).getCharacter() + " (Active)" 
                << "||";
    } else {
      std::cout << std::string(20, ' ') << "||";
    }
    if (i < player2->getRosterSize()) {
      std::cout << std::setw(20) << std::right
                << "(Active) " + player2->getCharacterAtIndex(i).getCharacter()
                << std::endl;
    } else {
      std::cout << std::string(20, ' ') << std::endl; //OUTPUTS BLANK IF CHARACTER DOES NOT EXIT
    }
  } else {
    if (i < player1->getRosterSize()) {
      std::cout << std::setw(20) << std::left
                << player1->getCharacterAtIndex(i).getCharacter() << "||"; //OUTPUTS NAME
    } else {
      std::cout << std::string(20, ' ') << "||";
    }
    if (i < player2->getRosterSize()) {
      std::cout << std::setw(20) << std::right
                << player2->getCharacterAtIndex(i).getCharacter() << std::endl;
    } else {
      std::cout << std::string(20, ' ') << std::endl;
    }
  }
  if (i < player1->getRosterSize()) {
    std::cout << std::setw(20) << std::left
              << std::string(player1->getCharacterAtIndex(i).getHealth(), '*') //DISPLAYS HEALTH
              << "||";
  } else {
    std::cout << std::string(20, ' ') << "||";
  }
  if (i < player2->getRosterSize()) {
    std::cout << std::setw(20) << std::right
              << std::string(player2->getCharacterAtIndex(i).getHealth(), '*')
              << std::endl;
  } else {
    std::cout << std::string(20, ' ') << std::endl;
  }
  if (i < player1->getRosterSize()) {
    std::cout << std::setw(20) << std::left
              << std::string(player1->getCharacterAtIndex(i).getAttack(), '+') //DISPLAYS ATTACK VALUE
              << "||";
  } else {
    std::cout << std::string(20, ' ') << "||";
  }
  if (i < player2->getRosterSize()) {
    std::cout << std::setw(20) << std::right
              << std::string(player2->getCharacterAtIndex(i).getAttack(), '+')
              << std::endl;
  } else {
    std::cout << std::string(20, ' ') << std::endl;
  }
  if (i < player1->getRosterSize()) {
    std::cout << std::setw(20) << std::left
              << std::string(player1->getCharacterAtIndex(i).getDefense(), '-') //DISPLAYS DEFENSE
              << "||";
  } else {
    std::cout << std::string(20, ' ') << "||";
  }
  if (i < player2->getRosterSize()) {
    std::cout << std::setw(20) << std::right
              << std::string(player2->getCharacterAtIndex(i).getDefense(), '-')
              << std::endl;
  } else {
    std::cout << std::string(20, ' ') << std::endl;
  }
  std::cout << std::string(42, '=') << std::endl;
}

void displayScoreBoard(Team *player1, Team *player2, int round) { //DISPLAYS THE TEAM INFORMATION
  std::cout << std::endl;
  const int rosterSize = 3;
  const int lineWidth = 42;
  const int columnWidth = 20;
  std::cout << std::setw(23) << "Round  " << round << std::endl;
  std::cout << std::string(42, '=') << std::endl;
  std::cout << std::setw(columnWidth) << std::left
            << "\"" + player1->getTeamName() + "\""
            << "||" << std::setw(columnWidth) << std::right
            << "\"" + player2->getTeamName() + "\"" << std::endl;
  std::cout << std::setw(columnWidth) << std::left << player1->getTurnPoints()
            << "||" << std::setw(columnWidth) << std::right
            << player2->getTurnPoints() << std::endl;
  std::cout << std::setw(columnWidth) << std::left << player1->getRosterSize()
            << "||" << std::setw(columnWidth) << std::right
            << player2->getRosterSize() << std::endl;
  std::cout << std::string(lineWidth, '=') << std::endl;
  for (int i = 0; i < rosterSize; i++) {
    displayCharacterInfo(player1, player2, i);
  }
  std::cout << std::endl;
}

#endif