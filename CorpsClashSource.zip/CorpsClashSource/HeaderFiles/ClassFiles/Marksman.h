#ifndef MARKSMAN_H
#define MARKSMAN_H
#include "Character.h"
class Marksman : public Character {
public:
  Marksman(std::string characterNameInput, int healthInput, int attackInput,
           int defenseInput) {
    characterName = characterNameInput;
    health = healthInput;
    attack = attackInput;
    defense = defenseInput;
    maxHP = healthInput;
  } //SETS THE MARKSMAN STATS

  ~Marksman() {
    std::cout << characterName << " has been defeated" << std::endl;
  }

  void getCharacterInfo() const override { //OUTPUTS CHARACTER INFO
    std::cout << std::endl << "Marksman" << std::endl;
    std::cout << "HP: 16" << std::endl;
    std::cout << "Attack: 7" << std::endl;
    std::cout << "Defense: 2" << std::endl << std::endl;
    std::cout << "Passive: every attack will increase attack by 1. Marksman "
              << std::endl
              << "can have a maximum of 3 stacks." << std::endl
              << std::endl;
    std::cout << "Special Attack: Marksman will do devastating amounts of "
              << std::endl
              << "damage based on defenses." << std::endl
              << std::endl;
    std::cout << "Ability: Marksman will gain the ability to attack non active"
              << std::endl
              << "Characters." << std::endl
              << std::endl;
  }
  int activatePassive() override {
    shotIncrease++;
    if (shotIncrease == 4) {
      shotIncrease = 0; //EVERY ATTACK, THE DAMAGE WILL INCREASE. MAX OF 4 STACKS, THEN IT WILL RESET
    }
    attack = defaultAttack + shotIncrease;
    return attack;
  }
  int getSpecialAttack(int value) override { return attack + value + value; } //MARKSMAN WILL DO EXTRA DAMAGE BASED ON VALUE

private:
  int shotIncrease = 0;
  int defaultAttack = 7;
};
#endif