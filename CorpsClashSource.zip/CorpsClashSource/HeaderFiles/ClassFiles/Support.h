#ifndef SUPPORT_H
#define SUPPORT_H
#include "Character.h"
class Support : public Character {
public:
  Support(std::string characterNameInput, int healthInput, int attackInput,
          int defenseInput) {
    characterName = characterNameInput;
    health = healthInput;
    attack = attackInput;
    defense = defenseInput;
    maxHP = healthInput;
  } //SETS THE SUPPORT STATS

  ~Support() {
    std::cout << characterName << " has been defeated" << std::endl;
  }

  void getCharacterInfo() const override { //OUTPUTS CHARACTER INFO
    std::cout << std::endl << "Support" << std::endl;
    std::cout << "HP: 12" << std::endl;
    std::cout << "Attack: 5" << std::endl;
    std::cout << "Defense: 3" << std::endl << std::endl;
    std::cout << "Passive: Every other attack will heal support by 2."
              << std::endl
              << std::endl;
    std::cout << "Special Attack: Support will deal damage and heal based on "
              << std::endl
              << "enemy defenses." << std::endl
              << std::endl;
    std::cout << "Ability: Support will gain the ability to heal an ally or "
              << std::endl
              << "damage an enemy based on how much HP support has." << std::endl
              << std::endl;
  }

  int activatePassive() override {
    if (selfHeal) { //SUPPORT WILL HEAL EVERY OTHER ATTACK
      health += 2;
    }
    selfHeal = !selfHeal;
    return attack;
  }

  int getSpecialAttack(int value) override {
    health += value;
    return attack; //SUPPORT WILL HEAL BASED ON VALUE
  }

private:
  bool selfHeal = false;
};
#endif