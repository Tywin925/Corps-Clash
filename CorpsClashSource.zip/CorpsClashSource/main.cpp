#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>

#include "HeaderFiles/ClassFiles/Assassin.h"
#include "HeaderFiles/ClassFiles/Bruiser.h"
#include "HeaderFiles/ClassFiles/Character.h"
#include "HeaderFiles/ClassFiles/Marksman.h"
#include "HeaderFiles/ClassFiles/Support.h"
#include "HeaderFiles/ClassFiles/Tank.h"
#include "HeaderFiles/ClassFiles/Team.h"

#include "HeaderFiles/characterAbility.h"
#include "HeaderFiles/displayBoard.h"
#include "HeaderFiles/gameLoop.h"
#include "HeaderFiles/setGameUp.h"


int main() {
  outputMenu("TextFiles/Start.txt"); //OUTPUTS START MENU
  std::string start;
  std::cin >> start;
  startInput(start);
  const int ROSTER_SIZE = 3;
  Team *Player1 = nullptr;  //CREATES PLAYER 1
  Team *Player2 = nullptr;  //CREATES PLAYER 2

  if (start == "1") {
    chooseTeam(Player1, ROSTER_SIZE, 1); //CHOOSES PLAYER 1 TEAM
    chooseTeam(Player2, ROSTER_SIZE, 2); //CHOOSES PLAYER 2 TEAM
  } else if (start == "2") {
    loadGameFile("TextFiles/SaveFile.txt", Player1, Player2);  //LOADS SAVE FILE
  } else {  //ENDS GAME BEFORE DOING ANYTHING
    std::cout << "Goodbye" << std::endl;
    delete Player1;
    delete Player2;
    return 1;
  }
  int round = 1;
  outputMenu("TextFiles/GameInfo.txt"); //LOADS GAME INSTRUCTIONS
  std::string gameOption = "3";
  while (gameOption == "3") { //OPTION 3 STARTS THE NEXT ROUND
    displayScoreBoard(Player1, Player2, round);
    outputMenu("TextFiles/GameOption.txt");
    std::cout << std::endl;
    std::cin >> gameOption; 

    while (gameOption != "1" && gameOption != "2" && gameOption != "3") {
      std::cout << "Please input a valid integer" << std::endl; 
      std::cin >> gameOption;
    }
    if (gameOption == "1") { //OPTION 1 SAVES THE GAME
      SaveFile(Player1, Player2);
      std::cout << "Game Saved" << std::endl
                << "Choose to continue or exit" << std::endl;
      std::cin >> gameOption; //ASKS USER TO LEAVE OR START NEXT ROUND
      while (gameOption != "2" && gameOption != "3") {
        std::cout << "Please input a valid integer" << std::endl;
        std::cin >> gameOption;
      }
    }
    if (gameOption == "2") { //OPTION 2 ENDS THE GAME
      delete Player1;
      delete Player2;
      return 1;
    }
    performGameLoop(Player1, Player2, round); //GAME LOOP STARTS HERE
    if (Player1->getRosterSize() == 0) { //ENDS GAME IF PLAYER 1 REACHES 0 CHARACTERS
      outputMenu("TextFiles/trophy.txt");
      std::cout << Player2->getTeamName() << " Wins" << std::endl;
      delete Player1;
      delete Player2; 
      return 1;
    }
    if (Player2->getRosterSize() == 0) { //ENDS GAME IF PLAYER 2 REACHES 0 CHARACTERS
      outputMenu("TextFiles/trophy.txt");
      std::cout << Player1->getTeamName() << " Wins" << std::endl;
      delete Player1;
      delete Player2;
      return 1;
    }
    round++;
  }
  delete Player1;
  delete Player2;

  return 0;
}