#ifndef CHARACTER_ABILITY
#define CHARACTER_ABILITY
#include "ClassFiles/Team.h"
#include "setGameUp.h"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>

void characterAbility(Team *&attackingPlayer, Team *&defendingPlayer,
                      bool &playerTurn) {
  int input, active = 0;
  if (attackingPlayer->getCharacterAtIndex(active).getCharacter() == "Assassin") { 
    //ABILITY ALLOWS ASSASSIN TO ATTACK AND SWITCH IN THE SAME TURN
    outputMenu("TextFiles/AsciiArt/Assassin.txt");
    attackingPlayer->useAttack(defendingPlayer, active);
    if (attackingPlayer->getRosterSize() > 1) {
      std::cout << "Choose a character to switch to" << std::endl;
      std::cin >> input; //INPUT FOR A CHARACTER TO SWITCH TO
      while (input < 2 || input > attackingPlayer->getRosterSize()) {
        std::cout << "Invalid input, try again" << std::endl;
        std::cin >> input;
      }
      attackingPlayer->useSwitch(input);
    } else {
      playerTurn = !playerTurn; //IF ROSTER SIZE OF ATTACKING PLAYER IS 1 THEN THE TURN GOES BACK TO ATTACKING PLAYER
    }
  } else if (attackingPlayer->getCharacterAtIndex(active).getCharacter() == "Marksman") { 
    //ABILITY ALLOWS MARKSMAN TO TARGET ANY CHARACTER
    outputMenu("TextFiles/AsciiArt/Marksman.txt");
    std::cout << "Choose a character to attack" << std::endl;
    std::cin >> input; //INPUT TO CHOOSE WHICH CHARACTER TO ATTACK
    while (input < 1 || input > defendingPlayer->getRosterSize()) {
      std::cout << "Invalid input, try again" << std::endl;
      std::cin >> input;
    }
    attackingPlayer->useAttack(defendingPlayer, input - 1);
  } else if (attackingPlayer->getCharacterAtIndex(active).getCharacter() == "Bruiser") { 
    //ABILITY ALLOWS BRUISER TO CHANGE THE ACTIVE CHARACTER OF ENEMY. WILL ALSO DEAL DAMAGE TO PREVIOUS ACTIVE CHARACTER BASED ON THE HEALTH OF NEW ACTIVE CHARACTER
      outputMenu("TextFiles/AsciiArt/Bruiser.txt");
      std::cout << "Choose a character to throw" << std::endl;
      std::cin >> input; //INPUT TO CHOOSE A CHARACTER TO THROW
      while (input < 1 || input > defendingPlayer->getRosterSize()) {
        std::cout << "Invalid input, try again" << std::endl;
        std::cin >> input;
      }
      defendingPlayer->getCharacterAtIndex(active).setHealth(
          (defendingPlayer->getCharacterAtIndex(active).getHealth() +
           defendingPlayer->getCharacterAtIndex(active).getDefense()) -
          (defendingPlayer->getCharacterAtIndex(input - 1).getHealth() / 2)); //DAMAGE DEALT BASED ON CHARACTER HP THROWN
      defendingPlayer->useSwitch(input); //SWITCHES TO NEW CHARACTER
    
  } else if (attackingPlayer->getCharacterAtIndex(active).getCharacter() == "Tank") { 
    //ABILITY ALLOWS TANK TO STUN ENEMY AND FORCES ENEMY TO SWITCH CHARACTERS AND ENDING THEIR TURN
    outputMenu("TextFiles/AsciiArt/Tank.txt");
    attackingPlayer->useAttack(defendingPlayer, active);
    ;
    if (defendingPlayer->getRosterSize() > 1) { //CHECKS IF THEIR ROSTER HAS MORE THAN 1 CHARACTER. IF NOT, ENEMY TURN WILL BE PASSED
      std::cout << defendingPlayer->getCharacterAtIndex(active).getCharacter()
                << " Has been stunned" << std::endl;
      std::cout << "Player 2 choose a character to switch to" << std::endl;
      std::cin >> input;
      while (input < 2 || input > defendingPlayer->getRosterSize()) {
        std::cout << "Invalid input, try again" << std::endl;
        std::cin >> input;
      }
      defendingPlayer->useSwitch(input); //DEFENDING PLAYER MUST SWITCH OUT OF THEIR STUNNED CHARACTER
      playerTurn = !playerTurn;
    } else {
      std::cout << defendingPlayer->getCharacterAtIndex(active).getCharacter()
                << " Has been stunned" << std::endl;
      playerTurn = !playerTurn;
    }
  }

  else if (attackingPlayer->getCharacterAtIndex(active).getCharacter() == "Support") {
    //ABILITY ALLOWS SUPPORT TO HEAL AN ALLY OR DAMAGE AN ENEMY (DEFENSES WILL BE IGNORED)
    outputMenu("TextFiles/AsciiArt/Support.txt");
    std::string choice;
    std::cout << "Would you like to heal or damage an enemy" << std::endl;
    std::cin >> choice;
    while (choice != "heal" && choice != "damage") {
      std::cout << "Invalid input, try again" << std::endl;
      std::cin >> choice; //ASKS WHETHER TO HEAL ALLY OR DAMAGE ENEMY
    }
    if (choice == "heal") {
      std::cout << "Input an ally" << std::endl;
      std::cin >> input;
      while (input < 1 || input > defendingPlayer->getRosterSize()) {
        std::cout << "Invalid input, try again" << std::endl;
        std::cin >> input;
      }
      input--; 
      attackingPlayer->getCharacterAtIndex(input).setHealth( 
          attackingPlayer->getCharacterAtIndex(input).getHealth() + 6); //HEALTH OF ALLY WILL INCREASE BY 6
    }

    else if (choice == "damage") {
      std::cout << "Input an enemy" << std::endl;
      std::cin >> input;
      while (input < 1 || input > defendingPlayer->getRosterSize()) {
        std::cout << "Invalid input, try again" << std::endl;
        std::cin >> input;
      }
      input--;
      defendingPlayer->getCharacterAtIndex(input).setHealth(
          defendingPlayer->getCharacterAtIndex(input).getHealth() - 6); //HEALTH OF ENEMY WILL DECREASE BY 6
    }
  }
}
#endif