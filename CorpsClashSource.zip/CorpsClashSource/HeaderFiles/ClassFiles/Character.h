#ifndef CHARACTER_H
#define CHARACTER_H
#include <iostream>
#include <string>

class Character {
public:
  Character() {
    characterName = "Dead";
    health = 0;
    attack = 0;
    defense = 0;
    }

  virtual void getCharacterInfo() const = 0;
  virtual int activatePassive() = 0;
  virtual int getSpecialAttack(int) = 0; //PURE VIRTUAL FUNCTION
  
  std::string getCharacter() { return characterName; }
  int getDefense() { return defense; }
  int getAttack() { return attack; }    //GETTERS
  int getHealth() { 
    if (health > maxHP) { //IF HEALTH IS GREATER THAN MAX THEN IT RESETS IT TO MAX
      health = maxHP;
    }
    return health;
  }

  

  void setHealth(int changeHealth) { //CHANGES HEALTH
    health = changeHealth; }
 
  virtual ~Character() { std::cout << characterName << " is no longer in the team" << std::endl; }


protected:
  std::string characterName;
  int maxHP;
  int health;
  int attack;
  int defense;
};
#endif